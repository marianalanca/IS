package beans;

public interface IMail {
    void sendEmail();
}
